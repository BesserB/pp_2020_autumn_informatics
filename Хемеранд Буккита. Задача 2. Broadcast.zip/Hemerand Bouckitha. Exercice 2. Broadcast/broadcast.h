// Copyright 2020 Hemerand Bouckitha
#ifndef MODULES_TASK_2_HEMERAND_B_BCAST_BROADCAST_H_
#define MODULES_TASK_2_HEMERAND_B_BCAST_BROADCAST_H_

int MY_Bcast(void* buf, int count, MPI_Datatype type, int root, MPI_Comm comm);

#endif  // MODULES_TASK_2_HEMERAND_B_BCAST_BROADCAST_H_
